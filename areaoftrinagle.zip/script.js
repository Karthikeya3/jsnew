function trinagle(base,height){
     return 0.5*base*height;
}
const base=11;
const height =19;
const area=trinagle(base,height);
console.log("print the area" + area);